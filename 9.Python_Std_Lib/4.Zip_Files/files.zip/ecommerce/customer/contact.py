def contact_customer():
    print("Contacting customer")
